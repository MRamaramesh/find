package com.apssouza.validation;

/**
 * Valid entity interface
 *
 * @author apssouza
 */
public interface ValidEntity {

    boolean isValid();

}
